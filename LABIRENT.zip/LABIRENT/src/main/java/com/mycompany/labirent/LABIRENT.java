/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labirent;

import java.util.Scanner;

/**
 *
 * @author zeysu
 */
public class LABIRENT {

    private static boolean check = true;
    private static int x;
    private static int y;
    private static int t = 0;
    private static int r = 0;
    private static int h = 0;
    private static int f = 0;
    private static int adim_say = 0;
    private static int count = 0;
    private static int j = 1;

    public static void isinlanma(char[][] labirent, int[] basla) {
        int yeniSatir;
        int yeniSutun;
        boolean check1 = true;
        Scanner input = new Scanner(System.in);
        while (check1) {
            if (t > 0) {
                System.out.println("isinlanmak istediğiniz konumun satır numarasini giriniz:");
                x = input.nextInt();
                System.out.println("isinlanmak istediğiniz konumun sutun numarasini giriniz:");
                y = input.nextInt();
                yeniSatir = x;
                yeniSutun = y;
                int bonus = bonus_kontrol(labirent, yeniSatir, yeniSutun);
                if (yeniSatir < 0 || yeniSatir > labirent.length || yeniSutun < 0 || yeniSatir > labirent.length) {
                    System.out.println("Harita dısına ısınlanamazsınız. yeni deger giriniz.");
                } else {
                    if (labirent[yeniSatir][yeniSutun] == 'E') {
                        adim_say++;
                        System.out.println("bitis noktasına geldiniz adim sayiniz:" + adim_say);
                        check1 = false;
                        check = false;
                    } else if (labirent[yeniSatir][yeniSutun] == '#' || labirent[yeniSatir][yeniSutun] == '!') {
                        System.out.println("mayina veya duvara ısınlanamazsınız.yeni deger girin");

                    } else {
                        if (!(labirent[basla[0]][basla[1]] == 'B')) {
                            labirent[basla[0]][basla[1]] = '.';
                        }
                        basla[0] = yeniSatir;
                        basla[1] = yeniSutun;
                        labirent[basla[0]][basla[1]] = 'X';

                        System.out.println("-----------" + adim_say + ".adım" + "------------");
                        for (int i = 0; i < labirent.length; i++) {
                            for (int j = 0; j < labirent[i].length; j++) {
                                System.out.print(labirent[i][j] + " ");
                            }
                            System.out.println();
                        }
                        System.out.println("konumun:" + basla[0] + ',' + basla[1]);

                        check1 = false;
                        t--;

                    }

                }
            } else {
                System.out.println("ısınlanma bonusunuz bulunmamaktadir.");
                check1 = false;
            }
        }
    }

    public static void random_bonus(char[] bonus, char[][] labirent) {
        int x;
        int y;

        for (int k = 0; k < bonus.length; k++) {

            boolean placed = true;

            while (placed) {
                if (j <= 5) {
                    x = (int) (Math.random() * 15);
                    y = (int) (Math.random() * 15);

                    if (!(labirent[x][y] == '#' || labirent[x][y] == 'B' || labirent[x][y] == 'E' || labirent[x][y] == '!' || labirent[x][y] == 'T' || labirent[x][y] == 'H' || labirent[x][y] == 'R' || labirent[x][y] == 'F')) {
                        labirent[x][y] = bonus[k];
                        j++;
                    }
                } else {
                    j = 1;
                    placed = false;
                }

            }
        }
    }

    public static void random_mayin(char[][] labirent) {

        int x;
        int y;
        char[] bonus = {'T', 'F', 'H', 'R'};
        while (count <= 10) {
            x = (int) (Math.random() * 15);
            y = (int) (Math.random() * 15);

            if (!(labirent[x][y] == '#' || labirent[x][y] == 'B' || labirent[x][y] == 'E' || labirent[x][y] == '!'
                    || labirent[x][y] == 'T' || labirent[x][y] == 'H' || labirent[x][y] == 'R' || labirent[x][y] == 'F')) {
                labirent[x][y] = '!';
                count++;
            }

        }

    }

    private static int bonus_kontrol(char[][] labirent, int yeniSatir, int yeniSutun) {
        char bonus = labirent[yeniSatir][yeniSutun];
        switch (bonus) {
            case 'T':
                t++;
                j++;

                break;
            case 'R':
                r++;
                j++;
                break;
            case 'H':
                h++;
                j++;
                break;
            case 'F':
                f++;
                j++;
                break;
        }
        return bonus;
    }

    public static void hareketEt(char[][] labirent, int[] basla, int satirdegisim, int sutundegisim) {
        boolean gecis = true;
        char[] bonus1 = {'T', 'F', 'H', 'R'};
        int yeniSatir;
        int yeniSutun;

        yeniSatir = basla[0] + satirdegisim;
        yeniSutun = basla[1] + sutundegisim;
        int bonus = bonus_kontrol(labirent, yeniSatir, yeniSutun);

        if (labirent[yeniSatir][yeniSutun] == '#') {
            if (r > 0) {
                r--;
            } else {
                gecis = false;
            }
        }
        if (labirent[yeniSatir][yeniSutun] == '!') {
            if (f > 0) {
                gecis = true;
                f--;
                count++;
            } else {
                adim_say += 5;
                gecis = false;
                labirent[yeniSatir][yeniSutun] = '.';
                random_mayin(labirent);
                random_bonus(bonus1, labirent);
            }
        }
        if (labirent[yeniSatir][yeniSutun] == 'E') {
            adim_say++;
            System.out.println("bitis noktasına geldiniz adim sayiniz:" + adim_say);
            check = false;

        }

        if (gecis) {
            if (!(labirent[basla[0]][basla[1]] == 'B')) {
                labirent[basla[0]][basla[1]] = '.';
            }
            basla[0] = yeniSatir;
            basla[1] = yeniSutun;
            labirent[basla[0]][basla[1]] = 'X';
            System.out.println("-----------" + adim_say + ".adım" + "------------");
            for (int i = 0; i < labirent.length; i++) {
                for (int j = 0; j < labirent[i].length; j++) {
                    System.out.print(labirent[i][j] + " ");
                }
                System.out.println();
            }
            System.out.println("konumun:" + basla[0] + ',' + basla[1]);

        } else {
            System.out.println("gecme bonusun yok adım sayınız:" + adim_say);
        }
    }

    public static void main(String[] args) {
        char[][] labirent = {{'#', '!', '.', '.', 'R', '.', '.', '.', '.', '.', '.', '#', '.', '.', '.'},
        {'.', '.', '#', '.', '.', '.', '#', '.', 'H', '.', '.', '.', '.', '.', '!'},
        {'F', '.', '.', '.', '#', '.', '!', '.', '.', 'R', '.', '.', '#', '#', '.'},
        {'.', '.', '#', '.', '.', '#', '.', '.', '.', '.', 'F', '.', '.', '.', '.'},
        {'.', '!', '.', '.', '#', '.', '#', '.', '#', '.', '.', '#', '.', '.', '.'},
        {'.', '.', 'H', '.', '.', '!', '.', '.', 'H', '.', '.', 'F', '.', '.', 'R'},
        {'#', '#', '#', '#', '.', '.', '#', '.', '.', '.', 'T', '.', '.', '.', 'E'},
        {'.', '.', '#', '.', 'F', '.', '#', '#', '.', '#', '#', '#', '#', '.', '.'},
        {'.', '#', '.', '.', '.', '.', '!', '.', '#', '.', '.', '.', '#', '.', '.'},
        {'.', 'T', 'T', '.', '#', '#', '.', '.', '.', '.', 'T', '.', '.', '.', 'R'},
        {'.', '.', '.', '#', '.', '.', '.', '#', '.', '#', '.', '#', '.', 'T', '.'},
        {'B', '.', '#', '.', '.', '!', '.', '!', '.', '.', '.', '.', '.', '.', '#'},
        {'.', '.', '.', 'F', '!', '.', '.', '.', 'H', '.', '.', 'R', '.', '.', '.'},
        {'.', '.', 'H', '.', '.', '.', '!', '.', '.', '.', '#', '.', '.', '#', '.'},
        {'.', '.', '.', '#', '.', '.', '#', '.', '#', '.', '#', '.', '.', '#', '#'}};

        char[] bonus = {'T', 'F', 'H', 'R'};
        int random_deg = 0;

        String b;

        int[] basla = new int[2];
        for (int i = 0; i < labirent.length; i++) {
            for (int j = 0; j < labirent[i].length; j++) {

                if (labirent[i][j] == 'B') {
                    basla[0] = i;
                    basla[1] = j;
                }

            }

        }
        System.out.println("---------oyun başladı---------");
        System.out.println("bulundugunuz konum:" + basla[0] + ',' + basla[1]);
        for (int i = 0; i < labirent.length; i++) {
            for (int j = 0; j < labirent[i].length; j++) {
                System.out.print(labirent[i][j] + " ");
            }
            System.out.println();
        }
        while (check) {

            if (random_deg % 5 == 0 && random_deg != 0) {
                for (int i = 0; i < labirent.length; i++) {
                    for (int j = 0; j < labirent[i].length; j++) {
                        if (!(labirent[i][j] == 'B' || labirent[i][j] == '#' || labirent[i][j] == 'E' || labirent[i][j] == 'X')) {
                            labirent[i][j] = '.';
                        }
                    }
                }
                count = 0;
                random_mayin(labirent);
                random_bonus(bonus, labirent);
            }

            System.out.println("W,A,S,D giriniz veya bonus kullanmak için '+' isaretine basınız. Çıkış için “cıkıs” yazınız.");
            System.out.println("bonuslarınız: T:" + t + " H:" + h + " R:" + r + " F:" + f);

            Scanner input = new Scanner(System.in);
            String ha = input.next().toUpperCase();

            if (ha.equals("CIKIS")) {
                System.out.println("oyundan cıkıs yaptınız. adım sayınız:" + adim_say);
                check = false;
            } else {
                adim_say++;
                if ((ha.equals("W") && basla[0] > 0)) {
                    hareketEt(labirent, basla, -1, 0);
                } else if ((ha.equals("A")) && (basla[1] > 0)) {
                    hareketEt(labirent, basla, 0, -1);
                } else if ((ha.equals("S") && basla[0] < labirent.length - 1)) {
                    hareketEt(labirent, basla, 1, 0);
                } else if ((ha.equals("D") && basla[1] < labirent[0].length - 1)) {
                    hareketEt(labirent, basla, 0, 1);
                } else if (ha.equals("+")) {

                    System.out.println("kullanmak istedigin bonus T veya H:");
                    b = input.next().toUpperCase();
                    if (b.equals("T")) {

                        if (t > 0) {
                            isinlanma(labirent, basla);

                        } else {
                            System.out.println("ısınlanma bonusunuz bulunmamaktadir.");

                        }

                    }
                    if (b.equals("H")) {
                        adim_say -= 2;
                        h--;
                    }

                }

                random_deg++;
            }
        }
    }
}
